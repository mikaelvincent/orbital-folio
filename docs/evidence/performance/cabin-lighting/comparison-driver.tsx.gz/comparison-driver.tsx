import { createRoot } from 'react-dom/client';
import { ImmersivePortfolio } from '../../features/portfolio/immersive-portfolio';
import { seeds } from '../../lib/content/seed';
import { toPortfolio } from '../../lib/content/types';
import './camera-invalidation-lab.css';

// Temporary comparison driver; same source in both isolated snapshots.
// Actual production-compiled portfolio, public seeds, fixed simulation, frozen Earth.
const panel = document.getElementById('camera-lab-controls')!;
panel.innerHTML = `<section class="camera-lab-panel"><h2>Lighting comparison</h2><p role="status">Loading</p><button id="hold" disabled>Record stationary</button><button id="motion" disabled>Record camera motion</button><button id="verify" disabled>Verify cache</button><textarea aria-label="Lighting report" readonly></textarea></section>`;
const status = panel.querySelector('p')!;
const output = panel.querySelector('textarea')!;
const buttons = [...panel.querySelectorAll('button')];
let controller: any;
let lost = false;
const viewport = () => [innerWidth, innerHeight, devicePixelRatio].join('x');
const data = toPortfolio(seeds.map(item => ({id:item.id,kind:item.kind,draft:item.data,published:item.data,revision:1,updatedAt:'2026-09-15T00:00:00.000Z'})) as any);
const step = () => new Promise<void>((resolve,reject) => requestAnimationFrame(() => {
  try { if(document.hidden || lost) throw new Error('Hidden or lost WebGL context'); controller.step(1/60); resolve(); } catch(error) { reject(error); }
}));
async function steps(count: number) { for(let i=0;i<count;i++) await step(); }
function clearInput() {
  (document.activeElement as HTMLElement)?.blur?.();
  const host = document.getElementById('ship')!;
  host.dispatchEvent(new PointerEvent('pointercancel',{bubbles:true,pointerId:913,isPrimary:true,pointerType:'mouse'}));
  host.dispatchEvent(new PointerEvent('pointerleave',{isPrimary:true,pointerType:'mouse'}));
  document.body.dispatchEvent(new KeyboardEvent('keydown',{key:'Tab',bubbles:true}));
}
function motion(frame: number) {
  const canvas=document.querySelector<HTMLCanvasElement>('#ship canvas')!;
  const box=canvas.getBoundingClientRect();
  const phase=(frame%120)/120*Math.PI*2;
  canvas.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,cancelable:true,pointerId:913,pointerType:'mouse',isPrimary:true,buttons:0,clientX:box.left+box.width*(.5+.2*Math.sin(phase)),clientY:box.top+box.height*(.5-.12*Math.sin(phase/2))}));
}
async function record(workload: string) {
  buttons.forEach(b=>b.disabled=true);
  const initialViewport=viewport();
  const startedAt=new Date().toISOString();
  try {
    clearInput();
    status.textContent='Warming up';
    controller.freezeBackground(0,true);
    await steps(180);
    controller.reset();
    const before=controller.state();
    const wall=performance.now();
    for(let i=0;i<600;i++) {
      if(viewport()!==initialViewport) throw new Error('Viewport changed');
      if(workload==='motion') motion(i);
      await step();
      if(i%60===0) status.textContent=`Recording ${workload}: ${i}/600`;
    }
    const report={workload,startedAt,endedAt:new Date().toISOString(),actualWallMs:performance.now()-wall,requestedFrames:600,stateBefore:before,stateAfter:controller.state(),report:controller.snapshot(),contextLost:lost,hidden:document.hidden,viewport:initialViewport,limitations:['Fixed-step synthetic motion, not native touch input','One browser/device; operating conditions not controlled','Last GPU queries may remain pending; no extra simulation frames']};
    output.value=JSON.stringify(report);
    status.textContent='Complete';
  } catch(error) { output.value=JSON.stringify({error:String(error)}); status.textContent='Failed'; }
  finally { buttons.forEach(b=>b.disabled=false); }
}
createRoot(document.getElementById('portfolio-root')!).render(<ImmersivePortfolio data={data} initialSection="projects" preview={false} sceneAudit={{manual:true,ready:async value=>{
  controller=value;
  controller.freezeBackground(0,true);
  controller.setPolicy('geometry');
  controller.setGpuScope('frame');
  document.querySelector('#ship canvas')?.addEventListener('webglcontextlost',()=>{lost=true;});
  await steps(240);
  if(!controller.state().backgroundReady) { status.textContent='Earth not ready'; return; }
  buttons.forEach(b=>b.disabled=false);
  status.textContent='Ready';
}}}><p>Public seed fixture</p></ImmersivePortfolio>);
document.getElementById('hold')!.onclick=()=>void record('stationary');
document.getElementById('motion')!.onclick=()=>void record('motion');
document.getElementById('verify')!.onclick=async()=>{
  buttons.forEach(b=>b.disabled=true);
  clearInput(); await steps(180);
  const result=controller.verifyFrame(true);
  output.value=JSON.stringify({verification:result,settings:controller.snapshot().settings});
  status.textContent='Cache verification complete';
  buttons.forEach(b=>b.disabled=false);
};
